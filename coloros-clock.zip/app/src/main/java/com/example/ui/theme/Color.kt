package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ColorOS 16 Aquamorphic Design Palette
val ColorOSPrimary = Color(0xFF00E5FF)
val ColorOSSecondary = Color(0xFF38BDF8)
val ColorOSTertiary = Color(0xFF818CF8)

val ColorOSDarkBg = Color(0xFF0B111E)
val ColorOSDarkSurface = Color(0xFF131E30)
val ColorOSDarkSurfaceVariant = Color(0xFF1E2D46)
val ColorOSDarkBorder = Color(0x3338BDF8)

val ColorOSTextPrimary = Color(0xFFF8FAFC)
val ColorOSTextSecondary = Color(0xFF94A3B8)
val ColorOSTextMuted = Color(0xFF64748B)

// Accent themes
val ThemeAquamorphic = Color(0xFF00E5FF)
val ThemeSunset = Color(0xFFFF6B6B)
val ThemeEmerald = Color(0xFF34D399)
val ThemeObsidian = Color(0xFFE2E8F0)
val ThemeLavender = Color(0xFFC084FC)
