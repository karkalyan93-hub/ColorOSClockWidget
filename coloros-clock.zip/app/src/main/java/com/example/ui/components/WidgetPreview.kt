package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widget.CardStyle
import com.example.widget.WidgetSettings
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class PreviewSizeMode(val label: String, val widthDp: Int, val heightDp: Int) {
    COMPACT("2x2 Compact", 170, 160),
    WIDE("4x2 Wide (Default)", 340, 150),
    EXPANDED("4x3 Tablet Large", 420, 230)
}

@Composable
fun LiveWidgetPreview(
    settings: WidgetSettings,
    sizeMode: PreviewSizeMode,
    batteryPercent: Int,
    isCharging: Boolean,
    modifier: Modifier = Modifier
) {
    // Ticking time state
    var currentTime by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            currentTime = Date()
            delay(1000L)
        }
    }

    val hourPattern = if (settings.is24Hour) "HH" else "hh"
    val hourStr = SimpleDateFormat(hourPattern, Locale.getDefault()).format(currentTime)
    val minStr = SimpleDateFormat("mm", Locale.getDefault()).format(currentTime)
    val secStr = SimpleDateFormat("ss", Locale.getDefault()).format(currentTime)
    val amPmStr = if (!settings.is24Hour) SimpleDateFormat("a", Locale.getDefault()).format(currentTime).uppercase() else ""
    val dayOfWeekStr = SimpleDateFormat("EEE", Locale.getDefault()).format(currentTime).uppercase()
    val dateStr = SimpleDateFormat("d MMM", Locale.getDefault()).format(currentTime).uppercase()
    val fullDateStr = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(currentTime)

    val theme = settings.theme
    val primaryColor = Color(theme.primaryColor)
    val accentColor = Color(theme.accentColor)
    val textPrimary = Color(theme.textPrimaryColor)
    val textSecondary = Color(theme.textSecondaryColor)
    val pillBg = Color(theme.pillBgColor)

    val cardBg = when (settings.cardStyle) {
        CardStyle.FROSTED_GLASS -> Color(theme.backgroundColor)
        CardStyle.FLOATING_MINIMAL -> Color.Transparent
        CardStyle.DEEP_CERAMIC -> Color(0xF00D1424)
    }

    val borderStrokeColor = when (settings.cardStyle) {
        CardStyle.FROSTED_GLASS -> Color(theme.borderColor)
        CardStyle.FLOATING_MINIMAL -> Color.Transparent
        CardStyle.DEEP_CERAMIC -> Color(0x4038BDF8)
    }

    val batteryLabel = if (isCharging) "⚡ $batteryPercent%" else "🔋 $batteryPercent%"

    Box(
        modifier = modifier
            .testTag("live_widget_preview_container")
            .size(sizeMode.widthDp.dp, sizeMode.heightDp.dp)
            .shadow(
                elevation = if (settings.cardStyle == CardStyle.FLOATING_MINIMAL) 0.dp else 16.dp,
                shape = RoundedCornerShape(28.dp)
            )
            .clip(RoundedCornerShape(28.dp))
            .background(cardBg)
            .border(
                width = if (settings.cardStyle == CardStyle.FLOATING_MINIMAL) 0.dp else 1.2.dp,
                color = borderStrokeColor,
                shape = RoundedCornerShape(28.dp)
            )
            .padding(18.dp),
        contentAlignment = Alignment.Center
    ) {
        when (sizeMode) {
            PreviewSizeMode.EXPANDED -> {
                // Tablet Large 4x3 Layout
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.Start
                ) {
                    // Top Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(pillBg)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "ColorOS 16 • Flux",
                                color = primaryColor,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (settings.showBattery) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(pillBg)
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = batteryLabel,
                                    color = textSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Middle Hero Clock
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = hourStr,
                            color = textPrimary,
                            fontSize = 62.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-1).sp
                        )

                        Text(
                            text = ":",
                            color = primaryColor,
                            fontSize = 58.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )

                        Text(
                            text = minStr,
                            color = textPrimary,
                            fontSize = 62.sp,
                            fontWeight = FontWeight.Normal,
                            letterSpacing = (-1).sp
                        )

                        if (settings.showSeconds) {
                            Text(
                                text = ":$secStr",
                                color = accentColor,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Light,
                                modifier = Modifier.padding(start = 4.dp, top = 20.dp)
                            )
                        }

                        if (amPmStr.isNotEmpty()) {
                            Spacer(modifier = Modifier.width(10.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(pillBg)
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = amPmStr,
                                    color = primaryColor,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Bottom info row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = fullDateStr,
                            color = textSecondary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )

                        if (settings.showAlarm) {
                            Text(
                                text = "⏰ Xiaomi Pad 8",
                                color = accentColor,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Normal
                            )
                        }
                    }
                }
            }

            PreviewSizeMode.WIDE -> {
                // Wide 4x2 Layout
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Left: Big Digits
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = hourStr,
                            color = textPrimary,
                            fontSize = 50.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = ":",
                            color = primaryColor,
                            fontSize = 46.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 2.dp)
                        )

                        Text(
                            text = minStr,
                            color = textPrimary,
                            fontSize = 50.sp,
                            fontWeight = FontWeight.Normal
                        )

                        if (settings.showSeconds) {
                            Text(
                                text = ":$secStr",
                                color = accentColor,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Light,
                                modifier = Modifier.padding(start = 2.dp, top = 16.dp)
                            )
                        }
                    }

                    // Right: Date & Battery Pill
                    Column(
                        modifier = Modifier.fillMaxHeight(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.End
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(pillBg)
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            val dateLabel = if (settings.showDayOfWeek) "$dayOfWeekStr, $dateStr" else dateStr
                            Text(
                                text = dateLabel,
                                color = primaryColor,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.End
                        ) {
                            if (settings.showBattery) {
                                Text(
                                    text = batteryLabel,
                                    color = textSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            if (amPmStr.isNotEmpty()) {
                                if (settings.showBattery) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                                Text(
                                    text = amPmStr,
                                    color = accentColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            PreviewSizeMode.COMPACT -> {
                // Compact 2x2 Layout
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = hourStr,
                            color = textPrimary,
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = ":",
                            color = primaryColor,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 2.dp)
                        )
                        Text(
                            text = minStr,
                            color = textPrimary,
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(pillBg)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "$dayOfWeekStr, $dateStr",
                            color = primaryColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
