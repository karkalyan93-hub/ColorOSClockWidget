package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessLow
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widget.WidgetSettings
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DeskClockScreen(
    settings: WidgetSettings,
    batteryPercent: Int,
    isCharging: Boolean,
    onClose: () -> Unit
) {
    BackHandler { onClose() }

    var isDimmed by remember { mutableStateOf(false) }
    var currentTime by remember { mutableStateOf(Date()) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTime = Date()
            delay(1000L)
        }
    }

    val alphaAnim by animateFloatAsState(
        targetValue = if (isDimmed) 0.35f else 1.0f,
        animationSpec = tween(500),
        label = "dim_anim"
    )

    val hourPattern = if (settings.is24Hour) "HH" else "hh"
    val hourStr = SimpleDateFormat(hourPattern, Locale.getDefault()).format(currentTime)
    val minStr = SimpleDateFormat("mm", Locale.getDefault()).format(currentTime)
    val secStr = SimpleDateFormat("ss", Locale.getDefault()).format(currentTime)
    val amPmStr = if (!settings.is24Hour) SimpleDateFormat("a", Locale.getDefault()).format(currentTime).uppercase() else ""
    val fullDateStr = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(currentTime)

    val theme = settings.theme
    val primaryColor = Color(theme.primaryColor)
    val textPrimary = Color(theme.textPrimaryColor)
    val textSecondary = Color(theme.textSecondaryColor)
    val pillBg = Color(theme.pillBgColor)

    val batteryLabel = if (isCharging) "⚡ $batteryPercent% Charging" else "🔋 $batteryPercent%"

    Box(
        modifier = Modifier
            .testTag("desk_clock_fullscreen")
            .fillMaxSize()
            .background(Color(0xFF06090F))
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {
                // Tap anywhere to toggle dimming
                isDimmed = !isDimmed
            }
            .padding(24.dp)
    ) {
        // Top Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .alpha(alphaAnim),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(pillBg)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Xiaomi Pad 8 • ColorOS 16 Desk Clock",
                        color = primaryColor,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Text(
                    text = if (isDimmed) "Tap to brighten" else "Tap screen to dim",
                    color = textSecondary,
                    fontSize = 12.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { isDimmed = !isDimmed },
                    modifier = Modifier.testTag("dim_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isDimmed) Icons.Default.BrightnessMedium else Icons.Default.BrightnessLow,
                        contentDescription = "Toggle Brightness",
                        tint = textSecondary
                    )
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier.testTag("close_desk_clock_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Desk Clock",
                        tint = textPrimary
                    )
                }
            }
        }

        // Center Grand Time
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .alpha(alphaAnim),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = hourStr,
                    color = textPrimary,
                    fontSize = 110.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-2).sp
                )

                Text(
                    text = ":",
                    color = primaryColor,
                    fontSize = 98.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Text(
                    text = minStr,
                    color = textPrimary,
                    fontSize = 110.sp,
                    fontWeight = FontWeight.Normal,
                    letterSpacing = (-2).sp
                )

                Column(
                    modifier = Modifier.padding(start = 12.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    if (amPmStr.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(pillBg)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = amPmStr,
                                color = primaryColor,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    Text(
                        text = secStr,
                        color = primaryColor,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = fullDateStr,
                color = textSecondary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(100.dp))
                    .background(Color(0x331E293B))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = batteryLabel,
                    color = textSecondary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Bottom subtle footer
        Text(
            text = "Xiaomi Pad 8 144Hz • Fluid Aquamorphic Engine",
            color = Color(0x6094A3B8),
            fontSize = 12.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .alpha(alphaAnim)
        )
    }
}
