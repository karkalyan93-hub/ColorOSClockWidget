package com.example.ui.components

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

data class WallpaperPreset(
    val id: String,
    val name: String,
    val brush: Brush,
    val previewColor: Color
)

object WallpaperRepository {
    val presets = listOf(
        WallpaperPreset(
            id = "oceanic",
            name = "Aquamorphic Wave",
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF031926),
                    Color(0xFF0B2545),
                    Color(0xFF134074),
                    Color(0xFF003049)
                )
            ),
            previewColor = Color(0xFF134074)
        ),
        WallpaperPreset(
            id = "sunset",
            name = "Sunset Horizon",
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0xFF370617),
                    Color(0xFF6A040F),
                    Color(0xFF9D0208),
                    Color(0xFFD00000),
                    Color(0xFFE85D04)
                )
            ),
            previewColor = Color(0xFFD00000)
        ),
        WallpaperPreset(
            id = "emerald",
            name = "Emerald Peak",
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF021B14),
                    Color(0xFF064E3B),
                    Color(0xFF047857),
                    Color(0xFF0F172A)
                )
            ),
            previewColor = Color(0xFF047857)
        ),
        WallpaperPreset(
            id = "cosmic",
            name = "Cosmic Nebula",
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0xFF1E0B36),
                    Color(0xFF3B0764),
                    Color(0xFF581C87),
                    Color(0xFF172554)
                )
            ),
            previewColor = Color(0xFF581C87)
        ),
        WallpaperPreset(
            id = "obsidian",
            name = "Obsidian Slate",
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF0B0F19),
                    Color(0xFF111827),
                    Color(0xFF1E293B),
                    Color(0xFF0F172A)
                )
            ),
            previewColor = Color(0xFF1E293B)
        )
    )
}
