package com.example.ui.screens

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.LiveWidgetPreview
import com.example.ui.components.PreviewSizeMode
import com.example.ui.components.WallpaperPreset
import com.example.ui.components.WallpaperRepository
import com.example.widget.CardStyle
import com.example.widget.ColorOSClockWidgetReceiver
import com.example.widget.ColorOSTheme
import com.example.widget.WidgetSettings
import com.example.widget.WidgetSettingsRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenDeskClock: () -> Unit
) {
    val context = LocalContext.current
    var settings by remember { mutableStateOf(WidgetSettingsRepository.load(context)) }
    var selectedWallpaper by remember { mutableStateOf(WallpaperRepository.presets.first()) }
    var selectedSizeMode by remember { mutableStateOf(PreviewSizeMode.WIDE) }
    var showHelpDialog by remember { mutableStateOf(false) }

    // Live battery info
    var batteryInfo by remember { mutableStateOf(WidgetSettingsRepository.getBatteryInfo(context)) }

    fun updateSettings(newSettings: WidgetSettings) {
        settings = newSettings
        WidgetSettingsRepository.save(context, newSettings)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "ColorOS 16 Clock",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0x3300E5FF))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Xiaomi Pad 8",
                                color = Color(0xFF00E5FF),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = onOpenDeskClock,
                        modifier = Modifier.testTag("open_desk_clock_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.NightlightRound,
                            contentDescription = "Desk Clock Mode",
                            tint = Color(0xFF00E5FF)
                        )
                    }
                    IconButton(
                        onClick = { showHelpDialog = true },
                        modifier = Modifier.testTag("open_help_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = "Widget Setup Guide",
                            tint = Color(0xFF94A3B8)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0B111E),
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFF0B111E)
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isTabletExpanded = maxWidth >= 760.dp

            if (isTabletExpanded) {
                // Two-Pane Tablet Layout for Xiaomi Pad 8
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    // Left Pane: Wallpaper Stage & Widget Preview
                    Box(
                        modifier = Modifier
                            .weight(1.1f)
                            .fillMaxHeight()
                    ) {
                        WallpaperStage(
                            settings = settings,
                            selectedWallpaper = selectedWallpaper,
                            selectedSizeMode = selectedSizeMode,
                            batteryPercent = batteryInfo.first,
                            isCharging = batteryInfo.second,
                            onWallpaperSelect = { selectedWallpaper = it },
                            onSizeModeSelect = { selectedSizeMode = it },
                            onPinWidget = { pinWidgetToHomeScreen(context) }
                        )
                    }

                    // Right Pane: Customizer Controls
                    Box(
                        modifier = Modifier
                            .weight(0.9f)
                            .fillMaxHeight()
                    ) {
                        CustomizerPanel(
                            settings = settings,
                            onSettingsChange = { updateSettings(it) },
                            onOpenDeskClock = onOpenDeskClock,
                            onShowGuide = { showHelpDialog = true }
                        )
                    }
                }
            } else {
                // Compact / Portrait Single Column
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    WallpaperStage(
                        settings = settings,
                        selectedWallpaper = selectedWallpaper,
                        selectedSizeMode = selectedSizeMode,
                        batteryPercent = batteryInfo.first,
                        isCharging = batteryInfo.second,
                        onWallpaperSelect = { selectedWallpaper = it },
                        onSizeModeSelect = { selectedSizeMode = it },
                        onPinWidget = { pinWidgetToHomeScreen(context) }
                    )

                    CustomizerPanel(
                        settings = settings,
                        onSettingsChange = { updateSettings(it) },
                        onOpenDeskClock = onOpenDeskClock,
                        onShowGuide = { showHelpDialog = true }
                    )
                }
            }
        }
    }

    if (showHelpDialog) {
        WidgetSetupGuideDialog(onDismiss = { showHelpDialog = false })
    }
}

@Composable
fun WallpaperStage(
    settings: WidgetSettings,
    selectedWallpaper: WallpaperPreset,
    selectedSizeMode: PreviewSizeMode,
    batteryPercent: Int,
    isCharging: Boolean,
    onWallpaperSelect: (WallpaperPreset) -> Unit,
    onSizeModeSelect: (PreviewSizeMode) -> Unit,
    onPinWidget: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2D)),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0x3338BDF8)))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header with size switcher
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Live Wallpaper Stage",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PreviewSizeMode.values().forEach { mode ->
                        val isSelected = selectedSizeMode == mode
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF00E5FF) else Color(0x22FFFFFF))
                                .clickable { onSizeModeSelect(mode) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = mode.label.split(" ").first(),
                                color = if (isSelected) Color(0xFF00363D) else Color(0xFF94A3B8),
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            // Simulated Tablet Wallpaper Screen
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(selectedWallpaper.brush),
                contentAlignment = Alignment.Center
            ) {
                // Live Interactive Widget Preview
                LiveWidgetPreview(
                    settings = settings,
                    sizeMode = selectedSizeMode,
                    batteryPercent = batteryPercent,
                    isCharging = isCharging
                )
            }

            // Wallpaper selector row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Wallpapers:",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                WallpaperRepository.presets.forEach { preset ->
                    val isSelected = selectedWallpaper.id == preset.id
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(preset.previewColor)
                            .border(
                                width = if (isSelected) 2.5.dp else 1.dp,
                                color = if (isSelected) Color(0xFF00E5FF) else Color(0x40FFFFFF),
                                shape = CircleShape
                            )
                            .clickable { onWallpaperSelect(preset) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Selected",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // Pin to Home Screen Action
            Button(
                onClick = onPinWidget,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pin_widget_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00E5FF),
                    contentColor = Color(0xFF00363D)
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Widgets,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Add ColorOS 16 Widget to Home Screen",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
fun CustomizerPanel(
    settings: WidgetSettings,
    onSettingsChange: (WidgetSettings) -> Unit,
    onOpenDeskClock: () -> Unit,
    onShowGuide: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2D)),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0x3338BDF8)))
    ) {
        Column(
            modifier = Modifier
                .padding(18.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Palette,
                    contentDescription = null,
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "Widget Customizer Studio",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            // 1. ColorOS Theme Palette Swatches
            Text(
                text = "COLOR PALETTE",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ColorOSTheme.values().forEach { themeOption ->
                    val isSelected = settings.theme == themeOption
                    Card(
                        modifier = Modifier
                            .clickable { onSettingsChange(settings.copy(theme = themeOption)) }
                            .widthIn(min = 100.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color(0x3300E5FF) else Color(0x1A1E293B)
                        ),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = androidx.compose.ui.graphics.SolidColor(
                                if (isSelected) Color(themeOption.primaryColor) else Color(0x22FFFFFF)
                            )
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color(themeOption.primaryColor))
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = themeOption.title.split(" ").first(),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            // 2. Card Aesthetics
            Text(
                text = "CARD AESTHETIC",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CardStyle.values().forEach { style ->
                    val isSelected = settings.cardStyle == style
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) Color(0x3300E5FF) else Color(0x1A1E293B))
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) Color(0xFF00E5FF) else Color(0x22FFFFFF),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onSettingsChange(settings.copy(cardStyle = style)) }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = style.title,
                            color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            // 3. Format & Feature Toggles
            Text(
                text = "DISPLAY PREFERENCES",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            SettingToggleRow(
                title = "24-Hour Military Format",
                subtitle = "Display 14:48 instead of 02:48 PM",
                checked = settings.is24Hour,
                onCheckedChange = { onSettingsChange(settings.copy(is24Hour = it)) }
            )

            SettingToggleRow(
                title = "Show Battery Status Pill",
                subtitle = "Real-time battery % and charging lightning icon",
                checked = settings.showBattery,
                onCheckedChange = { onSettingsChange(settings.copy(showBattery = it)) }
            )

            SettingToggleRow(
                title = "Show Day of Week",
                subtitle = "E.g. FRI, 30 OCT",
                checked = settings.showDayOfWeek,
                onCheckedChange = { onSettingsChange(settings.copy(showDayOfWeek = it)) }
            )

            SettingToggleRow(
                title = "Show Seconds (Desk / Preview)",
                subtitle = "Display live seconds counter",
                checked = settings.showSeconds,
                onCheckedChange = { onSettingsChange(settings.copy(showSeconds = it)) }
            )

            SettingToggleRow(
                title = "Xiaomi Pad 8 Tablet Badge",
                subtitle = "Contextual tablet system indicator",
                checked = settings.showAlarm,
                onCheckedChange = { onSettingsChange(settings.copy(showAlarm = it)) }
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Quick Actions: Desk Clock & Setup Guide
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(
                    onClick = onOpenDeskClock,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.NightlightRound,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Desk Clock", fontSize = 12.sp)
                }

                FilledTonalButton(
                    onClick = onShowGuide,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Setup Guide", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x10FFFFFF))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = subtitle,
                color = Color(0xFF64748B),
                fontSize = 11.sp
            )
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF00363D),
                checkedTrackColor = Color(0xFF00E5FF),
                uncheckedThumbColor = Color(0xFF94A3B8),
                uncheckedTrackColor = Color(0x33475569)
            )
        )
    }
}

private fun pinWidgetToHomeScreen(context: Context) {
    val appWidgetManager = AppWidgetManager.getInstance(context)
    val myProvider = ComponentName(context, ColorOSClockWidgetReceiver::class.java)

    if (appWidgetManager.isRequestPinAppWidgetSupported) {
        appWidgetManager.requestPinAppWidget(myProvider, null, null)
        Toast.makeText(context, "Requesting widget pin on Xiaomi Pad 8...", Toast.LENGTH_SHORT).show()
    } else {
        Toast.makeText(
            context,
            "Please long-press the home screen and choose 'Widgets' -> 'ColorOS Clock'",
            Toast.LENGTH_LONG
        ).show()
    }
}

@Composable
fun WidgetSetupGuideDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Widgets,
                    contentDescription = null,
                    tint = Color(0xFF00E5FF)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "How to add on Xiaomi Pad 8", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Follow these simple steps on your Xiaomi Pad 8 / HyperOS launcher:",
                    color = Color.White,
                    fontSize = 13.sp
                )
                GuideStep(number = "1", text = "Go to your tablet home screen.")
                GuideStep(number = "2", text = "Pinch with two fingers or long-press on an empty spot.")
                GuideStep(number = "3", text = "Tap the 'Widgets' icon at the bottom.")
                GuideStep(number = "4", text = "Scroll down and find 'ColorOS Clock'.")
                GuideStep(number = "5", text = "Touch and hold the widget, then drag it to your preferred position.")
                GuideStep(number = "6", text = "Resize the widget horizontally (4x2 or 4x3) to experience the full tablet magazine clock layout!")
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF))
            ) {
                Text(text = "Got it", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
            }
        },
        containerColor = Color(0xFF131D2D),
        titleContentColor = Color.White
    )
}

@Composable
fun GuideStep(number: String, text: String) {
    Row(
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(Color(0xFF00E5FF)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                color = Color(0xFF00363D),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Text(
            text = text,
            color = Color(0xFFCBD5E1),
            fontSize = 12.sp,
            modifier = Modifier.weight(1f)
        )
    }
}
