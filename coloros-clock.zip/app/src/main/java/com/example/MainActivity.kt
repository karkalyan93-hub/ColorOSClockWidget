package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.ui.screens.DeskClockScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.widget.WidgetSettingsRepository

enum class AppScreen {
    HOME,
    DESK_CLOCK
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme(darkTheme = true) {
                var currentScreen by remember { mutableStateOf(AppScreen.HOME) }
                val (batteryPercent, isCharging) = remember {
                    WidgetSettingsRepository.getBatteryInfo(this@MainActivity)
                }
                val settings = remember {
                    WidgetSettingsRepository.load(this@MainActivity)
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0B111E)
                ) {
                    Crossfade(
                        targetState = currentScreen,
                        label = "screen_transition"
                    ) { screen ->
                        when (screen) {
                            AppScreen.HOME -> {
                                HomeScreen(
                                    onOpenDeskClock = { currentScreen = AppScreen.DESK_CLOCK }
                                )
                            }
                            AppScreen.DESK_CLOCK -> {
                                DeskClockScreen(
                                    settings = settings,
                                    batteryPercent = batteryPercent,
                                    isCharging = isCharging,
                                    onClose = { currentScreen = AppScreen.HOME }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
