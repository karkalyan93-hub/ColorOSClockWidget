package com.example.widget

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalContext
import androidx.glance.LocalSize
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.example.MainActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ColorOSClockWidget : GlanceAppWidget() {

    override val sizeMode: SizeMode = SizeMode.Responsive(
        setOf(
            COMPACT_SIZE,
            WIDE_SIZE,
            TABLET_EXPANDED_SIZE
        )
    )

    companion object {
        val COMPACT_SIZE = DpSize(130.dp, 120.dp)
        val WIDE_SIZE = DpSize(240.dp, 100.dp)
        val TABLET_EXPANDED_SIZE = DpSize(340.dp, 160.dp)
    }

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent {
            val ctx = LocalContext.current
            val size = LocalSize.current
            val settings = WidgetSettingsRepository.load(ctx)
            val now = Date()

            val hourPattern = if (settings.is24Hour) "HH" else "hh"
            val hourStr = SimpleDateFormat(hourPattern, Locale.getDefault()).format(now)
            val minStr = SimpleDateFormat("mm", Locale.getDefault()).format(now)
            val amPmStr = if (!settings.is24Hour) SimpleDateFormat("a", Locale.getDefault()).format(now).uppercase() else ""
            val dayOfWeekStr = SimpleDateFormat("EEE", Locale.getDefault()).format(now).uppercase()
            val dateStr = SimpleDateFormat("d MMM", Locale.getDefault()).format(now).uppercase()
            val fullDateStr = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(now)

            val (batteryPct, isCharging) = WidgetSettingsRepository.getBatteryInfo(ctx)
            val batteryLabel = if (isCharging) "⚡ $batteryPct%" else "🔋 $batteryPct%"

            val theme = settings.theme
            val primaryColor = Color(theme.primaryColor)
            val accentColor = Color(theme.accentColor)
            val textPrimary = Color(theme.textPrimaryColor)
            val textSecondary = Color(theme.textSecondaryColor)

            val cardBg = when (settings.cardStyle) {
                CardStyle.FROSTED_GLASS -> Color(theme.backgroundColor)
                CardStyle.FLOATING_MINIMAL -> Color.Transparent
                CardStyle.DEEP_CERAMIC -> Color(0xF00A0F1A)
            }
            val pillBg = Color(theme.pillBgColor)

            Box(
                modifier = GlanceModifier
                    .fillMaxSize()
                    .cornerRadius(28.dp)
                    .background(cardBg)
                    .padding(14.dp)
                    .clickable(actionStartActivity<MainActivity>()),
                contentAlignment = Alignment.Center
            ) {
                when {
                    size.width >= 320.dp -> {
                        // Expanded Tablet Layout (Xiaomi Pad 8)
                        TabletExpandedClockContent(
                            hourStr = hourStr,
                            minStr = minStr,
                            amPmStr = amPmStr,
                            fullDateStr = fullDateStr,
                            batteryLabel = batteryLabel,
                            primaryColor = primaryColor,
                            accentColor = accentColor,
                            textPrimary = textPrimary,
                            textSecondary = textSecondary,
                            pillBg = pillBg,
                            settings = settings
                        )
                    }
                    size.width >= 210.dp -> {
                        // Standard Wide 4x2 Layout
                        WideClockContent(
                            hourStr = hourStr,
                            minStr = minStr,
                            amPmStr = amPmStr,
                            dayOfWeekStr = dayOfWeekStr,
                            dateStr = dateStr,
                            batteryLabel = batteryLabel,
                            primaryColor = primaryColor,
                            accentColor = accentColor,
                            textPrimary = textPrimary,
                            textSecondary = textSecondary,
                            pillBg = pillBg,
                            settings = settings
                        )
                    }
                    else -> {
                        // Compact 2x2 Layout
                        CompactClockContent(
                            hourStr = hourStr,
                            minStr = minStr,
                            dayOfWeekStr = dayOfWeekStr,
                            dateStr = dateStr,
                            primaryColor = primaryColor,
                            accentColor = accentColor,
                            textPrimary = textPrimary,
                            textSecondary = textSecondary,
                            pillBg = pillBg
                        )
                    }
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun TabletExpandedClockContent(
    hourStr: String,
    minStr: String,
    amPmStr: String,
    fullDateStr: String,
    batteryLabel: String,
    primaryColor: Color,
    accentColor: Color,
    textPrimary: Color,
    textSecondary: Color,
    pillBg: Color,
    settings: WidgetSettings
) {
    Column(
        modifier = GlanceModifier.fillMaxSize(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalAlignment = Alignment.Start
    ) {
        // Top status row
        Row(
            modifier = GlanceModifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = GlanceModifier
                    .cornerRadius(12.dp)
                    .background(pillBg)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "ColorOS 16 • Flux",
                    style = TextStyle(
                        color = ColorProvider(primaryColor),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = GlanceModifier.defaultWeight())

            if (settings.showBattery) {
                Box(
                    modifier = GlanceModifier
                        .cornerRadius(12.dp)
                        .background(pillBg)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = batteryLabel,
                        style = TextStyle(
                            color = ColorProvider(textSecondary),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }

        Spacer(modifier = GlanceModifier.height(4.dp))

        // Center Hero Clock Numbers
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = hourStr,
                style = TextStyle(
                    color = ColorProvider(textPrimary),
                    fontSize = 58.sp,
                    fontWeight = FontWeight.Bold
                )
            )

            Text(
                text = ":",
                style = TextStyle(
                    color = ColorProvider(primaryColor),
                    fontSize = 54.sp,
                    fontWeight = FontWeight.Bold
                ),
                modifier = GlanceModifier.padding(horizontal = 2.dp)
            )

            Text(
                text = minStr,
                style = TextStyle(
                    color = ColorProvider(textPrimary),
                    fontSize = 58.sp,
                    fontWeight = FontWeight.Normal
                )
            )

            if (amPmStr.isNotEmpty()) {
                Spacer(modifier = GlanceModifier.width(8.dp))
                Box(
                    modifier = GlanceModifier
                        .cornerRadius(8.dp)
                        .background(pillBg)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = amPmStr,
                        style = TextStyle(
                            color = ColorProvider(primaryColor),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = GlanceModifier.height(4.dp))

        // Bottom Date & Extra row
        Row(
            modifier = GlanceModifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = fullDateStr,
                style = TextStyle(
                    color = ColorProvider(textSecondary),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            )

            if (settings.showAlarm) {
                Spacer(modifier = GlanceModifier.defaultWeight())
                Text(
                    text = "⏰ Xiaomi Pad 8",
                    style = TextStyle(
                        color = ColorProvider(accentColor),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal
                    )
                )
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun WideClockContent(
    hourStr: String,
    minStr: String,
    amPmStr: String,
    dayOfWeekStr: String,
    dateStr: String,
    batteryLabel: String,
    primaryColor: Color,
    accentColor: Color,
    textPrimary: Color,
    textSecondary: Color,
    pillBg: Color,
    settings: WidgetSettings
) {
    Row(
        modifier = GlanceModifier.fillMaxSize(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left Column: Big Bold Time
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = hourStr,
                style = TextStyle(
                    color = ColorProvider(textPrimary),
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Bold
                )
            )

            Text(
                text = ":",
                style = TextStyle(
                    color = ColorProvider(primaryColor),
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Bold
                ),
                modifier = GlanceModifier.padding(horizontal = 2.dp)
            )

            Text(
                text = minStr,
                style = TextStyle(
                    color = ColorProvider(textPrimary),
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Normal
                )
            )
        }

        Spacer(modifier = GlanceModifier.width(12.dp))

        // Right Column: Date Pill & Battery
        Column(
            modifier = GlanceModifier.fillMaxHeight(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalAlignment = Alignment.Start
        ) {
            // Date badge
            Box(
                modifier = GlanceModifier
                    .cornerRadius(12.dp)
                    .background(pillBg)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                val dateLabel = if (settings.showDayOfWeek) "$dayOfWeekStr, $dateStr" else dateStr
                Text(
                    text = dateLabel,
                    style = TextStyle(
                        color = ColorProvider(primaryColor),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = GlanceModifier.height(6.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (settings.showBattery) {
                    Text(
                        text = batteryLabel,
                        style = TextStyle(
                            color = ColorProvider(textSecondary),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }

                if (amPmStr.isNotEmpty()) {
                    if (settings.showBattery) {
                        Spacer(modifier = GlanceModifier.width(6.dp))
                    }
                    Text(
                        text = amPmStr,
                        style = TextStyle(
                            color = ColorProvider(accentColor),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun CompactClockContent(
    hourStr: String,
    minStr: String,
    dayOfWeekStr: String,
    dateStr: String,
    primaryColor: Color,
    accentColor: Color,
    textPrimary: Color,
    textSecondary: Color,
    pillBg: Color
) {
    Column(
        modifier = GlanceModifier.fillMaxSize(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = hourStr,
                style = TextStyle(
                    color = ColorProvider(textPrimary),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold
                )
            )
            Text(
                text = ":",
                style = TextStyle(
                    color = ColorProvider(primaryColor),
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold
                )
            )
            Text(
                text = minStr,
                style = TextStyle(
                    color = ColorProvider(textPrimary),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Normal
                )
            )
        }

        Spacer(modifier = GlanceModifier.height(6.dp))

        Box(
            modifier = GlanceModifier
                .cornerRadius(10.dp)
                .background(pillBg)
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text(
                text = "$dayOfWeekStr, $dateStr",
                style = TextStyle(
                    color = ColorProvider(primaryColor),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            )
        }
    }
}
