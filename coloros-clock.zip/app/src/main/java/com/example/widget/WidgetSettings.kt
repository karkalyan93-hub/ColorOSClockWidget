package com.example.widget

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.ui.graphics.Color
import androidx.glance.appwidget.GlanceAppWidgetManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * ColorOS 16 Flux Theme color palettes.
 */
enum class ColorOSTheme(
    val title: String,
    val primaryColor: Long,       // 0xAARRGGBB
    val accentColor: Long,
    val backgroundColor: Long,
    val borderColor: Long,
    val textPrimaryColor: Long,
    val textSecondaryColor: Long,
    val pillBgColor: Long
) {
    AQUAMORPHIC(
        title = "Aquamorphic Cyan",
        primaryColor = 0xFF00E5FF,
        accentColor = 0xFF38BDF8,
        backgroundColor = 0xD90D1B2A,
        borderColor = 0x6600E5FF,
        textPrimaryColor = 0xFFFFFFFF,
        textSecondaryColor = 0xFFA5F3FC,
        pillBgColor = 0x4000E5FF
    ),
    SUNSET(
        title = "Sunset Glow",
        primaryColor = 0xFFFF6B6B,
        accentColor = 0xFFFBBF24,
        backgroundColor = 0xD92D1219,
        borderColor = 0x66FF6B6B,
        textPrimaryColor = 0xFFFFFFFF,
        textSecondaryColor = 0xFFFDE68A,
        pillBgColor = 0x40FF6B6B
    ),
    EMERALD(
        title = "Emerald Jade",
        primaryColor = 0xFF34D399,
        accentColor = 0xFF6EE7B7,
        backgroundColor = 0xD90A231C,
        borderColor = 0x6634D399,
        textPrimaryColor = 0xFFFFFFFF,
        textSecondaryColor = 0xFFA7F3D0,
        pillBgColor = 0x4034D399
    ),
    OBSIDIAN(
        title = "Obsidian Dark",
        primaryColor = 0xFFFFFFFF,
        accentColor = 0xFF94A3B8,
        backgroundColor = 0xE60B0F19,
        borderColor = 0x55475569,
        textPrimaryColor = 0xFFFFFFFF,
        textSecondaryColor = 0xFFCBD5E1,
        pillBgColor = 0x33475569
    ),
    LAVENDER(
        title = "Lavender Mist",
        primaryColor = 0xFFC084FC,
        accentColor = 0xFFE879F9,
        backgroundColor = 0xD9201035,
        borderColor = 0x66C084FC,
        textPrimaryColor = 0xFFFFFFFF,
        textSecondaryColor = 0xFFE9D5FF,
        pillBgColor = 0x40C084FC
    )
}

enum class CardStyle(val title: String) {
    FROSTED_GLASS("Frosted Glass"),
    FLOATING_MINIMAL("Floating Minimal"),
    DEEP_CERAMIC("Deep Ceramic")
}

data class WidgetSettings(
    val theme: ColorOSTheme = ColorOSTheme.AQUAMORPHIC,
    val cardStyle: CardStyle = CardStyle.FROSTED_GLASS,
    val is24Hour: Boolean = false,
    val showBattery: Boolean = true,
    val showDayOfWeek: Boolean = true,
    val showAlarm: Boolean = true,
    val showSeconds: Boolean = false
)

object WidgetSettingsRepository {
    private const val PREFS_NAME = "coloros_clock_widget_prefs"
    private const val KEY_THEME = "key_theme"
    private const val KEY_CARD_STYLE = "key_card_style"
    private const val KEY_24H = "key_24h"
    private const val KEY_SHOW_BATTERY = "key_show_battery"
    private const val KEY_SHOW_DAY = "key_show_day"
    private const val KEY_SHOW_ALARM = "key_show_alarm"
    private const val KEY_SHOW_SECONDS = "key_show_seconds"

    fun load(context: Context): WidgetSettings {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val themeName = prefs.getString(KEY_THEME, ColorOSTheme.AQUAMORPHIC.name)
        val styleName = prefs.getString(KEY_CARD_STYLE, CardStyle.FROSTED_GLASS.name)

        val theme = runCatching { ColorOSTheme.valueOf(themeName ?: "") }.getOrDefault(ColorOSTheme.AQUAMORPHIC)
        val cardStyle = runCatching { CardStyle.valueOf(styleName ?: "") }.getOrDefault(CardStyle.FROSTED_GLASS)

        return WidgetSettings(
            theme = theme,
            cardStyle = cardStyle,
            is24Hour = prefs.getBoolean(KEY_24H, false),
            showBattery = prefs.getBoolean(KEY_SHOW_BATTERY, true),
            showDayOfWeek = prefs.getBoolean(KEY_SHOW_DAY, true),
            showAlarm = prefs.getBoolean(KEY_SHOW_ALARM, true),
            showSeconds = prefs.getBoolean(KEY_SHOW_SECONDS, false)
        )
    }

    fun save(context: Context, settings: WidgetSettings) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_THEME, settings.theme.name)
            .putString(KEY_CARD_STYLE, settings.cardStyle.name)
            .putBoolean(KEY_24H, settings.is24Hour)
            .putBoolean(KEY_SHOW_BATTERY, settings.showBattery)
            .putBoolean(KEY_SHOW_DAY, settings.showDayOfWeek)
            .putBoolean(KEY_SHOW_ALARM, settings.showAlarm)
            .putBoolean(KEY_SHOW_SECONDS, settings.showSeconds)
            .apply()

        // Trigger Glance widget update across all active instances
        triggerGlanceUpdate(context)
    }

    fun triggerGlanceUpdate(context: Context) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val glanceManager = GlanceAppWidgetManager(context)
                val glanceIds = glanceManager.getGlanceIds(ColorOSClockWidget::class.java)
                val widget = ColorOSClockWidget()
                for (id in glanceIds) {
                    widget.update(context, id)
                }
            } catch (e: Exception) {
                // Ignore if no widgets are placed yet
            }
        }
    }

    /**
     * Helper to read current battery percentage & charging status without extra permissions.
     */
    fun getBatteryInfo(context: Context): Pair<Int, Boolean> {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val percentage = if (level >= 0 && scale > 0) {
            (level * 100) / scale
        } else {
            85 // Default reasonable fallback for preview/emulator
        }
        return Pair(percentage, isCharging)
    }
}
