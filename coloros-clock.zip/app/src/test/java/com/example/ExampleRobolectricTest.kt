package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.widget.CardStyle
import com.example.widget.ColorOSTheme
import com.example.widget.WidgetSettings
import com.example.widget.WidgetSettingsRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ColorOS Clock", appName)
  }

  @Test
  fun `widget settings load and save`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val initialSettings = WidgetSettingsRepository.load(context)
    assertNotNull(initialSettings)

    val updatedSettings = initialSettings.copy(
      theme = ColorOSTheme.SUNSET,
      cardStyle = CardStyle.DEEP_CERAMIC,
      is24Hour = true
    )
    WidgetSettingsRepository.save(context, updatedSettings)

    val loaded = WidgetSettingsRepository.load(context)
    assertEquals(ColorOSTheme.SUNSET, loaded.theme)
    assertEquals(CardStyle.DEEP_CERAMIC, loaded.cardStyle)
    assertEquals(true, loaded.is24Hour)
  }
}
